-- Example Star Schema for a Data Warehouse in Snowflake

-- Dimension Table: Customers
CREATE OR REPLACE TABLE dim_customers (
    customer_id INT PRIMARY KEY,
    customer_name STRING,
    region STRING,
    signup_date DATE
);

-- Dimension Table: Products
CREATE OR REPLACE TABLE dim_products (
    product_id INT PRIMARY KEY,
    product_name STRING,
    category STRING
);

-- Dimension Table: Time
CREATE OR REPLACE TABLE dim_time (
    date_key DATE PRIMARY KEY,
    year INT,
    quarter INT,
    month INT,
    day INT
);

-- Fact Table: Sales
CREATE OR REPLACE TABLE fact_sales (
    sales_id INT PRIMARY KEY,
    customer_id INT,
    product_id INT,
    date_key DATE,
    quantity INT,
    sales_amount FLOAT,
    FOREIGN KEY (customer_id) REFERENCES dim_customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES dim_products(product_id),
    FOREIGN KEY (date_key) REFERENCES dim_time(date_key)
);