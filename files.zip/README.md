# Data Architect Portfolio

This repository showcases various data architecture solutions, including samples for Snowflake (star schema), AWS Glue ETL, Azure Data Factory pipelines, and a portfolio summary.

## Structure

- `snowflake/`: Example SQL for star schema modeling in Snowflake
- `aws/`: Python ETL script for AWS Glue
- `azure/`: Sample Azure Data Factory pipeline definition
- `docs/`: Portfolio summary and documentation

## Author

Ramana-Data