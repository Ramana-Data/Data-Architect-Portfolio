"""
AWS Glue ETL Script Example: Load data from S3, transform, and write to another S3 location.
"""

import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job

args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Data source: S3 bucket
datasource = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    connection_options={"paths": ["s3://your-source-bucket/input/"]},
    format="csv",
    format_options={"withHeader": True}
)

# Example transformation: filter records
filtered = Filter.apply(frame=datasource, f=lambda x: x["status"] == "active")

# Write to S3 as Parquet
glueContext.write_dynamic_frame.from_options(
    frame=filtered,
    connection_type="s3",
    connection_options={"path": "s3://your-destination-bucket/output/"},
    format="parquet"
)

job.commit()