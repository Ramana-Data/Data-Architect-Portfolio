# Data Architect Portfolio Summary

This portfolio demonstrates practical data engineering and architecture skills using modern cloud platforms:

- **Snowflake:** Star schema SQL for scalable analytics.
- **AWS Glue:** ETL script for big data processing and automation.
- **Azure Data Factory:** Example pipeline for cloud data integration.

These samples reflect proficiency in designing, building, and managing end-to-end data solutions across leading cloud environments.